$(document).ready(function () {


    let myselfInformation=new Vue({
        el:'#main',
        data: {
            edit:false,
            modal:{
                modalHead:'',
                modalInput:'',
                sureAim:'',
                modalInputValue:'',
            },

            username:'LaLaLa',
            name:'夏浩',
            title:'啦啦啦啦啦',
            detail:'哈哈哈哈哈哈哈哈哈哈或或或或或或或或或或或或或或或或或或或或或或或或或哈哈哈哈哈哈哈哈哈哈或或或或或或或或或或或或或或或或或或或或或或或或或哈哈哈哈哈哈哈哈哈哈或或或或或或或或或或或或或或或或或或或或或或或或或',
            time:'2017/12/19',
            dormitoryName:'',
            dormitoryMember:'',
            dormitoryIdentity:'',
            mail:'471087639@qq.com',
            sex:'male',
            headImg:'',
            dormitoryId:'',

            inMessage:false,
            inDormitory:false,
            inMyselfInformation:true,
        },
        methods:{
            getMyselfInformation:function () {
                let that=this;
                let formdata=new FormData();
                // formdata.append('username',this.username);
                // formdata.append('password',this.password);
                new Interactive({
                    childPath:'/informationManagement/getMyselfInformation',
                    method:'POST',
                    detail:formdata,
                    successCallback:function (result) {
                        that.name=result.msg.name;
                        that.username=result.msg.username;
                        that.sex=result.msg.sex;
                        that.mail=result.msg.mail;
                        result.msg.img?that.headImg=result.msg.img:void (0);
                        result.msg.dormitoryId?that.dormitoryId=result.msg.dormitoryId:void (0);

                    },
                    errorCallback:function () {

                    },
                }).init();
            },
            createDormitory:function (needDormitoryName) {
                let that=this;
                let formdata=new FormData();
                formdata.append('dormitoryName',needDormitoryName);
                // formdata.append('password',this.password);
                new Interactive({
                    childPath:'/informationManagement/createDormitory',
                    method:'POST',
                    detail:formdata,
                    successCallback:function (result) {
                        PromptBox.displayPromptBox('创建宿舍'+needDormitoryName+'成功');
                        that.dormitoryName=needDormitoryName;
                    },
                    errorCallback:function (result) {
                        PromptBox.displayPromptBox('由于'+result.msg+',创建宿舍'+that.dormitoryName+'失败,请重试');
                    },
                }).init();
            },
            branchExecution:function () {
                console.log('a',this.modal.sureAim);
                this.modal.sureAim?this[this.modal.sureAim](this.modal.modalInputValue):void (0);
            },
            getMyselfInformation:function () {
                let that=this;
                let formdata=new FormData();
                // formdata.append('username',this.username);
                // formdata.append('password',this.password);
                new Interactive({
                    childPath:'/informationManagement/getMyselfInformation',
                    method:'POST',
                    detail:formdata,
                    successCallback:function (result) {
                        that.name=result.msg.name;
                        that.username=result.msg.username;
                        that.sex=result.msg.sex;
                        that.mail=result.msg.mail;
                        result.msg.img?that.headImg=result.msg.img:void (0);
                        result.msg.dormitoryId?that.dormitoryId=result.msg.dormitoryId:void (0);

                    },
                    errorCallback:function () {

                    },
                }).init();
            },
        },
        mounted:function () {
          this.getMyselfInformation();
        },
    })
})